#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Tamanho das variaveis\n");
    printf("%d\n", sizeof(int));
    printf("%d\n", sizeof(float));
    printf("%d\n", sizeof(double));
    printf("%d\n", sizeof(char));

    return 0;
}
