typedef struct cilindro Cilindro;

Cilindro* create(float altura,float raio);
float altura(Cilindro *cilindro_usuario);
float raio(Cilindro *cilindro_usuario);
float area(Cilindro *cilindro_usuario);
float volume(Cilindro *cilindro_usuario);
