typedef struct cubo Cubo;

Cubo* create(float lados); //criar nosso cubo
float area(const Cubo *cubo_usuario); //retorna a área do cubo
float volume(const Cubo *cubo_usuario); //retorna o volume do cubo
float lados(const Cubo *cubo_usuario); //retorna os lados do cubo
