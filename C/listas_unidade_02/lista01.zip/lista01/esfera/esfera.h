typedef struct esfera Esfera;

Esfera* create(float raio);
float raio(Esfera *esfera_user);
float area(Esfera *esfera_user);
float volume(Esfera *esfera_user);

